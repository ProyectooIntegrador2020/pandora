package modelo;

/**
 * Clase que contiene la informaci�n de cada arreglo que es necesario en un coche en concreto.
 * @author Helena Mart�nez
 * @author Loredana Alecci
 * @author Pedro Ribeiro
 *
 */
public class Arreglo {
	
	private String nombre;
	private float precio;
	
	public Arreglo(String nombre, float precio) {
		this.nombre = nombre;
		this.precio = precio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}
}
