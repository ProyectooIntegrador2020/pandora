package modelo;

public interface tipos_matricula_examen {

	public enum tipoMatricula {basico, intermedio, completo};
	
	public enum tipoExamen {teorico, practico};
}
